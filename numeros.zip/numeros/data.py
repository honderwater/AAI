from mnist import MNIST
from sklearn.metrics import accuracy_score
import pickle

print("Loading dataset...")
mndata = MNIST("C:\\Users\\HO\\Desktop\\programa final\\data\\")
images, labels = mndata.load_training()


#KNN CLASSIFIER
from sklearn.neighbors import KNeighborsClassifier
clf = KNeighborsClassifier()
# Train on the first 10000 images:
train_x = images[:10000]
train_y = labels[:10000]

print("Train model")
clf.fit(train_x, train_y)

# Test on the next 100 images:
test_x = images[10000:11000]
expected = labels[10000:11000].tolist()

print("Compute predictions")
predicted = clf.predict(test_x)

print("Accuracy KNN: ", accuracy_score(expected, predicted))

knnPickle = open('modelo', 'wb')
pickle.dump(clf, knnPickle)


#RANDOM FOREST
from sklearn.ensemble import RandomForestClassifier
clf2 = RandomForestClassifier(n_estimators=100)

# Train on the first 10000 images:
train_x = images[:30000]
train_y = labels[:30000]

#print("Train model")
clf2.fit(train_x, train_y)

# Test on the next 1000 images:
test_x = images[30000:31000]
expected = labels[30000:31000].tolist()

#print("Compute predictions")
predicted = clf2.predict(test_x)

print("Accuracy Random Tree: ", accuracy_score(expected, predicted))



#LINEAR SVC
from sklearn.svm import LinearSVC
clf3 = LinearSVC()

# Train on the first 10000 images:
train_x = images[:30000]
train_y = labels[:30000]

#print("Train model")
clf3.fit(train_x, train_y)

# Test on the next 1000 images:
test_x = images[30000:31000]
expected = labels[30000:31000].tolist()

#print("Compute predictions")
predicted = clf3.predict(test_x)

print("Accuracy Linear SVC: ", accuracy_score(expected, predicted))



#GUASSIAN NB
from sklearn.naive_bayes import GaussianNB
clf4 = GaussianNB()

train_x = images[:30000]
train_y = labels[:30000]

#print("Train model")
clf4.fit(train_x, train_y)

# Test on the next 1000 images:
test_x = images[30000:31000]
expected = labels[30000:31000].tolist()

#print("Compute predictions")
predicted = clf4.predict(test_x)

print("Accuracy Naive Bayes: ", accuracy_score(expected, predicted))

