import cv2
import numpy as np
import matplotlib.pyplot as plt
import pickle

def image_classif(image):
	#plt.imshow(image.squeeze(), cmap="gray")

	im2 = image.copy()
	im2 = 255 - im2
	thresh = cv2.adaptiveThreshold(im2, 1, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                                           cv2.THRESH_BINARY, 199, -6)
		                                  

	# find contours in the thresholded image and initialize the
	# shape detector
	cnts, hierarchy = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)

	number = []

	#aqui tb podes verificar se tens mais do q 1 contorno com muita area... os 2000
	for c in cnts:
	    area = cv2.contourArea(c)
	    if(area > 2000):
             number = c 
             break 
	
	if(len(number) == 0):
		return False, None

	x,y,w,h = cv2.boundingRect(number)
	#y = y - 25
	#x = x - 25
	#w = w + 50
	#h = h + 50
	ROI = image[y:y+h, x:x+w]

	#plt.imshow(ROI.squeeze(), cmap="gray")
	#plt.imshow(cv2.resize(ROI, (28, 28)).squeeze(), cmap="gray")

	cv2.imwrite('autocrop_resize.jpg', cv2.resize(ROI, (28, 28)).squeeze())

	autocrop_resize = cv2.imread("autocrop_resize.jpg")
	gray2 = cv2.cvtColor(autocrop_resize,cv2.COLOR_BGR2GRAY)
	autocrop_resize = gray2.flatten()
	numero = np.array(autocrop_resize, dtype = np.float32)
	numero = numero.reshape(-1, 784)


	loaded_model = pickle.load(open('modelo', 'rb'))
	result = loaded_model.predict(numero)

	return True, result

