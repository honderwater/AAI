

import cv2
import numpy as np
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
import matplotlib.pyplot as plt

digits = cv2.imread("digits2.png") #DIGITS2 É UMA SAMPLE COM 5000 NUMEROS, 500 SAMPLES DE CADA NUMERO DE 0 A 9
gray = cv2.cvtColor(digits,cv2.COLOR_BGR2GRAY)

test_digits = cv2.imread("test_digits.png") #TEST_DIGITS É A AMOSTRA PARA TESTAR O KNN.TRAIN, CONTEM 5 SAMPLES DE CADA NÚMERO
gray2 = cv2.cvtColor(test_digits,cv2.COLOR_BGR2GRAY)
#cv2.imshow('digits',binary)
cv2.waitKey()

rows = np.vsplit(gray, 50)

cells = []
for row in rows:
     row_cells = np.hsplit(row, 100)
     for cell in row_cells:
         cell = cell.flatten()
         cells.append(cell)
         
cells = np.array(cells, dtype = np.float32) 
cells = cells.reshape(-1, 400)
#print(cells.shape)         

k = np.arange(10)
labels = np.repeat(k, 500)

gray2_break = np.vsplit(gray2, 50)
test_cells =[]
for d in gray2_break :
    d = d.flatten()
    test_cells.append(d)
    
test_cells = np.array(test_cells, dtype = np.float32)
test_cells = test_cells.reshape(-1, 400)
#print(test_cells.shape)


test_labels = np.repeat(np.arange(10),5)

#KNN OPENCV

knn = cv2.ml.KNearest_create()
knn.train(cells, cv2.ml.ROW_SAMPLE ,labels)
#ret, result, neighbours, dist = knn.findNearest(test_cells, k=1)
#print(result)

#EEROU 2 TEST DIGITS EM 50

#KNN SKLEARN

clfKNN = KNeighborsClassifier()
clfKNN.fit(cells, labels)
#nl = clfKNN.predict(test_cells)
#print (nl)
#print(sum(nl != test_labels)/len(nl))

#ERROU 2 TEST DIGITS EM 50

#SVM SKLEARN

#clf = SVC(gamma='auto')
#clf.fit(cells, labels)
#cl = clf.predict(test_cells)
#print(cl)

#ERROU 1 TEST DIGITS EM 50










#GUARDAR O MODELO PARA NÃO TREINAR CADA VEZ QUE SE CORRE O PROGRAMA
#print(cells[3000])
#print(labels[3000])


#import csv
#row_list = [cells, labels]
#with open('model.csv', 'w', newline='') as file:
#    writer = csv.writer(file) 
#    writer.writerows(row_list)

#plt.imshow(test_cells[1])

