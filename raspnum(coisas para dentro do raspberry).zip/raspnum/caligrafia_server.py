from geventwebsocket.handler import WebSocketHandler
from gevent.pywsgi import WSGIServer
from flask import Flask, request, render_template
from time import sleep
import base64
import json
import numpy as np
import cv2

from classif import image_classif

app = Flask(__name__, template_folder = 'static') 

@app.route('/')
def index():
    return render_template('caligrafia.html') #ficheiro html onde o servidor vai buscar info 

@app.route('/camera')
def camera():

    if request.environ.get('wsgi.websocket'):
        ws = request.environ['wsgi.websocket']
        success = False
        
        

        while True:
            cam = cv2.VideoCapture(1)
            while True:
                imagem = cam.read()[1]
                buffer = cv2.imencode('.jpg', imagem)[1].tobytes()
                live_as_text = base64.b64encode(buffer).decode()
                ws.send('{"number":"' + str(live_as_text) + '"}')
                sleep(0.01)
                resp = ws.receive()
                
                py_resp = json.loads(resp)
                if(py_resp["aqc"]):
                    break

            #process image
            success, number_pred = image_classif(imagem) 
            
            if(success):
                
                ws.send('{"prediction":"' + str(number_pred) + '"}')
            else:
                ws.send('{"prediction":"erro"}')

if __name__ == '__main__':
   http_server = WSGIServer(("0.0.0.0", 9999), app, handler_class=WebSocketHandler)
   http_server.serve_forever()
